console.log("game.js chargé ✔️");

const paths = [
    document.getElementById('trackPath1'),
    document.getElementById('trackPath2'),
    document.getElementById('trackPath3'),
    document.getElementById('trackPath4')
];

const track = document.getElementById('raceContainer');

const totalLengths = paths.map(p => p.getTotalLength());
const maxLength = Math.max(...totalLengths);
let startOffsets = totalLengths.map(length => maxLength - length).reverse();

document.getElementById('startRace').addEventListener('click', async () => {
    if (selectedRunners.length !== 4) {
        alert("Sélectionne 4 coureurs avant de démarrer !");
        return;
    }

    const selectedPokemon = document.getElementById('selectedBetPokemon').value.trim();
    const betAmount = parseInt(document.getElementById('betAmount').value, 10);

    if (!selectedPokemon || isNaN(betAmount) || betAmount <= 0) {
        alert("Pari invalide !");
        return;
    }

    console.log(`✅ Pari sur : ${selectedPokemon}, mise : ${betAmount} pokédollars`);

    track.querySelectorAll('.runner-wrapper, .preview-runner').forEach(el => el.remove());

    const runners = [];

    for (let i = 0; i < selectedRunners.length; i++) {
        const pokeName = selectedRunners[i].trim();
        const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokeName.toLowerCase()}`);
        const data = await res.json();
        const spriteUrl = data.sprites.back_default;
        const spriteFront = data.sprites.front_default;

        const wrapper = document.createElement('div');
        wrapper.className = 'runner-wrapper';

        const img = document.createElement('img');
        img.src = spriteUrl;
        img.className = 'runner';

        if (pokeName.toLowerCase() === selectedPokemon.toLowerCase()) {
            if (window.activeBoost && window.activeBoost > 0) {
                img.classList.add('boosted-runner');
            }
        }

        const hpBar = document.createElement('div');
        hpBar.className = 'hp-bar';

        const hpFill = document.createElement('div');
        hpFill.className = 'hp-fill';
        hpBar.appendChild(hpFill);

        wrapper.appendChild(img);
        wrapper.appendChild(hpBar);
        track.appendChild(wrapper);

        runners.push({
            wrapper: wrapper,
            img: img,
            front: spriteFront,
            name: pokeName,
            strength: 50 + Math.floor(Math.random() * 20),
            defense: 30 + Math.floor(Math.random() * 20),
            healthPoint: 100,
            maxHealth: 100,
            // ✅ TypeChart complet pour API
            types: [{ Id: 1, Name: "Normal", Multiplier: 1.0 }],
            hpFill: hpFill
        });

        const point = paths[i].getPointAtLength(startOffsets[i]);
        wrapper.style.transform = `translate(${point.x - 25}px, ${point.y - 25}px)`;
    }

    const steps = [...startOffsets];
    let winnerIndex = -1;

    const interval = setInterval(() => {
        let finished = false;

        for (let i = 0; i < runners.length; i++) {
            if (steps[i] >= totalLengths[i]) continue;

            let baseSpeed = 8;
            let randomFactor = Math.random() * 6;

            const hpRatio = Math.max(0, runners[i].healthPoint) / runners[i].maxHealth;
            let speed = (baseSpeed + randomFactor) * hpRatio;

            if (runners[i].name.toLowerCase() === selectedPokemon.toLowerCase()) {
                speed += window.activeBoost || 0;
            }

            steps[i] = Math.max(0, steps[i] + speed);
            const clamped = Math.min(steps[i], totalLengths[i]);

            if (!Number.isFinite(clamped)) {
                console.error(`❌ Step NaN pour ${runners[i].name} (HP=${runners[i].healthPoint})`);
                continue;
            }

            const point = paths[i].getPointAtLength(clamped);
            runners[i].wrapper.style.transform = `translate(${point.x - 25}px, ${point.y - 25}px)`;

            if (steps[i] >= totalLengths[i] && winnerIndex === -1) {
                winnerIndex = i;
                finished = true;
            }
        }

        // ✅ Attaque seulement si 2+ vivants
        const alive = runners.filter(r => r.healthPoint > 0);
        if (Math.random() < 0.02 && alive.length >= 2) {
            let attacker = alive[Math.floor(Math.random() * alive.length)];
            let target = alive[Math.floor(Math.random() * alive.length)];
            while (target === attacker) {
                target = alive[Math.floor(Math.random() * alive.length)];
            }

            console.log(`⚡ ${attacker.name} attaque ${target.name}`);

            fetch('/api/Skills/use', {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    Attacker: {
                        name: attacker.name,
                        strength: attacker.strength,
                        defense: attacker.defense,
                        healthPoint: attacker.healthPoint,
                        types: attacker.types
                    },
                    Target: {
                        name: target.name,
                        strength: target.strength,
                        defense: target.defense,
                        healthPoint: target.healthPoint,
                        types: target.types
                    },
                    Skill: {
                        Id: 1,
                        Name: "Tackle",
                        Damage: 10,
                        PowerPoints: 10,
                        Accuracy: 95,
                        fk_type: 1
                    }
                })
            })
                .then(res => res.json())
                .then(data => {
                    const damage = Number(data.damageDealt);
                    if (!Number.isFinite(damage)) {
                        console.warn("❌ Dommage NaN => ignoré", data);
                        return;
                    }

                    console.log(`💥 ${attacker.name} inflige ${damage} à ${target.name}`);

                    target.healthPoint -= damage;
                    if (target.healthPoint < 0) target.healthPoint = 0;

                    target.hpFill.style.width = `${(target.healthPoint / target.maxHealth) * 100}%`;

                    steps[runners.indexOf(target)] = Math.max(0, steps[runners.indexOf(target)] - 20);

                    target.img.classList.add('attacked-runner');
                    setTimeout(() => target.img.classList.remove('attacked-runner'), 300);
                })
                .catch(err => console.error("Erreur attaque:", err));
        }

        if (finished) {
            clearInterval(interval);

            const winnerName = runners[winnerIndex].name.trim();
            const winnerSprite = runners[winnerIndex].front;

            console.log(`🏁 Gagnant : ${winnerName}`);
            console.log(`🎯 Ton pari : ${selectedPokemon}`);

            let gain = 0;
            if (winnerName.toLowerCase() === selectedPokemon.toLowerCase()) {
                gain = betAmount;
            }

            fetch('/api/player/update', {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    game: "PariPoke",
                    experience: 0,
                    pokedollar: gain
                })
            })
                .then(res => res.json())
                .then(data => {
                    console.log("✅ Réponse backend:", data);
                    document.getElementById('player-balance').innerText = data.pokedollar;
                })
                .catch(err => console.error("❌ Erreur maj pokédollars:", err));

            document.getElementById('victoryTitle').innerText = `Victoire de ${winnerName}!`;
            document.getElementById('victorySprite').src = winnerSprite;
            document.getElementById('victoryMessage').innerText = gain > 0
                ? `Bravo ! Tu remportes ${gain} pokédollars !`
                : `Dommage, tu perds ton pari.`;

            document.getElementById('victoryPopup').style.display = 'block';

            window.activeBoost = 0;
            const boostInfo = document.getElementById('boost-info');
            if (boostInfo) boostInfo.style.display = 'none';

            track.querySelectorAll('.runner-wrapper, .preview-runner').forEach(el => el.remove());
            PreviewUtils.buildPreviewRunners(selectedRunners);
        }
    }, 50);
});
